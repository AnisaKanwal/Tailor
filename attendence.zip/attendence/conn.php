<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "stumanagementstytem";
 $conn = new mysqli($servername, $username, $password, $database);
 if(!$conn){
    echo "Connection not made";
 }else{
    echo "connected successfully";
 }
?>